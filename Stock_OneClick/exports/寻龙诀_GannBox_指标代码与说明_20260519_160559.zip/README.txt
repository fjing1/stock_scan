寻龙诀 Gann Box 指标代码包

包含文件：

1. pine/寻龙诀_GannBox_V1.pine
   主图指标：Gann Box 0/1、0出/1出、MA窗口、BUY A/B/C、布林带等。

2. pine/寻龙诀_Panel_V1.pine
   附图指标：寻龙诀之分金、RSI、红绿柱、右侧趋势窗口。

3. docs/寻龙诀_GannBox_买卖点说明.md
   Markdown 说明文档。

4. docs/寻龙诀_GannBox_买卖点说明.txt
   纯文本说明文档，适合直接发送。

使用方式：
- 在 TradingView 新建 Pine Script 指标。
- 分别复制 .pine 文件内容到编辑器。
- 保存并添加到图表。

注意：
该指标用于技术分析辅助，不构成投资建议。
